#!/bin/bash

# Check if Python is installed
if ! command -v python3 &>/dev/null; then
    echo "Python is not installed. Please install Python 3."
    exit 1
fi

# Run the Python animation script

python3 "$HOME/cycle/cycle4.py"

